package com.joynit.bd.comp;

import com.joynit.bd.model.Birthday;

import java.time.LocalDate;
import java.util.Comparator;

public class BirthdayComparator implements Comparator<Birthday> {

    @Override
    public int compare(Birthday b1, Birthday b2) {
        LocalDate b1Date = b1.getDate();
        LocalDate b2Date = b2.getDate();

        // Compare birthdays based on date
        if (b1Date != null && b2Date != null) {
            int compareTo = b1Date.compareTo(b2Date);
            if (compareTo != 0) {
                return compareTo; // Return the result of date comparison
            }
        } else if (b1Date != null) {
            return -1; // b2 has null date, so b1 is considered greater
        } else if (b2Date != null) {
            return 1; // b1 has null date, so b2 is considered greater
        }

        // Compare birthdays based on name
        String b1Name = b1.getName();
        String b2Name = b2.getName();

        if (b1Name != null && b2Name != null) {
            return b1Name.compareTo(b2Name); // Return the result of name comparison
        } else if (b1Name != null) {
            return -1; // b2 has null name, so b1 is considered greater
        } else if (b2Name != null) {
            return 1; // b1 has null name, so b2 is considered greater
        }

        return 0; // Both birthdays have null name, consider them equal
    }

}