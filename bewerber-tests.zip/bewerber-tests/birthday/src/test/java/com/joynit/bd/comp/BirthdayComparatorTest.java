package com.joynit.bd.comp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

import org.junit.Test;

import com.joynit.bd.model.Birthday;

public class BirthdayComparatorTest {

	private BirthdayComparator birthdayComparator;

	public BirthdayComparatorTest() {
		birthdayComparator = new BirthdayComparator();
	}

	@Test
	public void testEqual() {
		Birthday lisa = new Birthday(LocalDate.of(2000, 01, 25), "Lisa");
		Birthday lisa2 = new Birthday(LocalDate.of(2000, 01, 25), "Lisa");

		int ret = birthdayComparator.compare(lisa, lisa2);
		assertEquals(0, ret);
	}

	@Test
	public void testEqual2() {
		Birthday lisa = new Birthday(null, "Lisa");
		Birthday lisa2 = new Birthday(null, "Lisa");

		int ret = birthdayComparator.compare(lisa, lisa2);
		assertEquals(0, ret);
	}

	@Test
	public void testEqual3() {
		Birthday lisa = new Birthday(null, null);
		Birthday lisa2 = new Birthday(null, null);

		int ret = birthdayComparator.compare(lisa, lisa2);
		assertEquals(0, ret);
	}

	@Test
	public void testFirst() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(LocalDate.of(2000, 01, 25), "Simon");

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testFirst2() {
		Birthday lisa = new Birthday(LocalDate.of(2000, 01, 25), "Lisa");
		Birthday simon = new Birthday(LocalDate.of(2000, 01, 25), "Simon");

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testFirst3() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(null, "Simon");

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testFirst4() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(null, null);

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testFirst5() {
		Birthday lisa = new Birthday(null, "Lisa");
		Birthday simon = new Birthday(null, "Simon");

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testFirst6() {
		Birthday lisa = new Birthday(null, "Lisa");
		Birthday simon = new Birthday(null, null);

		int ret = birthdayComparator.compare(lisa, simon);
		assertTrue(ret < 0);
	}

	@Test
	public void testSecond() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(LocalDate.of(2000, 01, 25), "Simon");

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testSecond2() {
		Birthday lisa = new Birthday(LocalDate.of(2000, 01, 25), "Lisa");
		Birthday simon = new Birthday(LocalDate.of(2000, 01, 25), "Simon");

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testSecond3() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(null, "Simon");

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testSecond4() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(null, null);

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testSecond5() {
		Birthday lisa = new Birthday(null, "Lisa");
		Birthday simon = new Birthday(null, "Simon");

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testSecond6() {
		Birthday lisa = new Birthday(null, "Lisa");
		Birthday simon = new Birthday(null, null);

		int ret = birthdayComparator.compare(simon, lisa);
		assertTrue(ret > 0);
	}

	@Test
	public void testList() {
		Birthday lisa = new Birthday(LocalDate.of(1993, 11, 04), "Lisa");
		Birthday simon = new Birthday(LocalDate.of(2000, 01, 25), "Simon");
		Birthday anna = new Birthday(LocalDate.of(1993, 11, 04), null);
		Birthday anton = new Birthday(null, "Anton");
		Birthday birgit = new Birthday(null, null);

		ArrayList<Birthday> birthdays = new ArrayList<>();
		Collections.addAll(birthdays, birgit, anton, anna, simon, lisa);
		Collections.sort(birthdays, birthdayComparator);

		for (Birthday birthday : birthdays) {
			System.out.println(birthday);
		}

		assertEquals(lisa, birthdays.get(0));
		assertEquals(anna, birthdays.get(1));
		assertEquals(simon, birthdays.get(2));
		assertEquals(anton, birthdays.get(3));
		assertEquals(birgit, birthdays.get(4));
	}

}
